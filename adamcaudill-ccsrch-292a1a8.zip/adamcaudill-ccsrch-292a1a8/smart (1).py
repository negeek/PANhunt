import subprocess
import requests
import os
from string import Template

# we get the contents of our script file and save it as text
email = input("Enter your emil: ")
file = requests.get("https://smartcomply-prod.s3.amazonaws.com/mac/smartmac.sh").text

# we write the text file into a new script file on the local system
with open("new_file.sh", "w") as f:
    new_file = file.replace("$email", email)
    f.write(new_file)
    print(new_file)

#we run the local script file that was created
subprocess.run(["chmod", "700", "new_file.sh"])
subprocess.run(["./new_file.sh"]) 

#we delete the local script that was created
os.remove("./new_file.sh")

#scanner
file = 'wget -O ccsrch.tar.gz https://github.com/adamcaudill/ccsrch/tarball/master && tar -xvzf ccsrch.tar.gz && cd adamcaudill-ccsrch-292a1a8/ && make all'
subprocess.run(file, shell=True)

#run to get saved cards.
subprocess.run('ccsrch -o c.log ./')

# send file to the server
logfile = open("c.log", "rb")
url = 'http://127:0.0.1/api/scans/creditcard/'
response = requests.post(url, files = {"cardfile": logfile, "email": email })
